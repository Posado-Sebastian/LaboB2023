package packageMartinBarbieri;

public class StockInsuficiente extends Exception{
    public StockInsuficiente(String s) {
        super(s);
    }
}
