package packageMartinBarbieri;

public class BebidaInexistente extends Exception{

    public BebidaInexistente(String s) {
        super(s);
    }
}
