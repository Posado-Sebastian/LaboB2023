package packageMartinBarbieri;

public class UsuarioDuplicado extends Exception{
    public UsuarioDuplicado(String s) {
        super(s);
    }
}
